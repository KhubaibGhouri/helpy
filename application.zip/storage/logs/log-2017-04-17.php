<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-17 09:38:42 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 09:38:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 09:38:42 --> Unable to connect to the database
ERROR - 2017-04-17 09:41:45 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 09:41:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 09:41:45 --> Unable to connect to the database
ERROR - 2017-04-17 09:45:48 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 09:45:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 09:45:48 --> Unable to connect to the database
ERROR - 2017-04-17 10:15:58 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 10:15:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 10:15:58 --> Unable to connect to the database
ERROR - 2017-04-17 10:19:02 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 10:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\easyappointments\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-17 10:19:02 --> Unable to connect to the database
ERROR - 2017-04-17 11:00:00 --> Email could not been sent. Mailer Error (Line 137): Could not instantiate mail function.
ERROR - 2017-04-17 11:00:00 --> #0 C:\xampp\htdocs\easyappointments\application\controllers\Appointments.php(455): EA\Engine\Notifications\Email->sendAppointmentDetails(Array, Array, Array, Array, Array, Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Text), Object(EA\Engine\Types\Url), Object(EA\Engine\Types\Email))
#1 [internal function]: Appointments->ajax_register_appointment()
#2 C:\xampp\htdocs\easyappointments\system\core\CodeIgniter.php(514): call_user_func_array(Array, Array)
#3 C:\xampp\htdocs\easyappointments\index.php(353): require_once('C:\\xampp\\htdocs...')
#4 {main}
ERROR - 2017-04-17 11:12:25 --> Invalid driver requested: Unit_tests_appointments_model
ERROR - 2017-04-17 11:12:44 --> Invalid driver requested: Unit_tests_appointments_model
