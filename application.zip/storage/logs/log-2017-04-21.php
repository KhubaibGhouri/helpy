<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-21 09:20:57 --> Severity: Notice --> Undefined variable: cur C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:20:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:21:21 --> Severity: Notice --> Undefined variable: cur C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:21:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:21:43 --> Severity: Notice --> Undefined variable: cur C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:21:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:21:59 --> Severity: Notice --> Undefined variable: cur C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:21:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:27:37 --> Severity: Notice --> Undefined variable: cur C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 09:27:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\helpy\application\views\profiles\index.php 20
ERROR - 2017-04-21 11:13:46 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\helpy\application\views\profiles\index.php 38
ERROR - 2017-04-21 11:15:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\helpy\application\views\profiles\index.php 39
ERROR - 2017-04-21 11:15:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\helpy\application\views\profiles\index.php 39
ERROR - 2017-04-21 11:15:31 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\helpy\application\views\profiles\index.php 40
ERROR - 2017-04-21 12:04:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\helpy\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-21 12:04:04 --> Unable to connect to the database
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 23
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 27
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 31
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 35
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 39
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 47
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 50
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 53
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 56
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 59
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 62
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 65
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 80
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 103
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 109
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 115
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 120
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 151
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\helpy\application\views\student\update.php 16
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 5
ERROR - 2017-04-21 13:50:52 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 8
ERROR - 2017-04-21 13:54:01 --> Severity: Notice --> Undefined property: stdClass::$zipcode C:\xampp\htdocs\helpy\application\views\student\update.php 39
ERROR - 2017-04-21 14:36:56 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) C:\xampp\htdocs\helpy\application\controllers\student.php 110
