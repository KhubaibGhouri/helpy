<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-18 08:32:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'easyappointments' C:\xampp\htdocs\helpy\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-04-18 08:32:44 --> Unable to connect to the database
ERROR - 2017-04-18 08:43:33 --> Invalid driver requested: Unit_tests_appointments_model
ERROR - 2017-04-18 08:44:49 --> Invalid driver requested: Unit_tests_appointments_model
ERROR - 2017-04-18 09:17:44 --> Severity: Notice --> Undefined property: Student::$session C:\xampp\htdocs\helpy\application\controllers\student.php 27
ERROR - 2017-04-18 09:17:44 --> Severity: Error --> Call to a member function userdata() on null C:\xampp\htdocs\helpy\application\controllers\student.php 27
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 22
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 26
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 30
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 34
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 38
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 46
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 49
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 52
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 55
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 58
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 61
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 64
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 78
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:38:34 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "services"
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "users"
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:38:35 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:38:35 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 166
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 22
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 26
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 30
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 34
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 38
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 46
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 49
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 52
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 55
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 58
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 61
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 64
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 78
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "services"
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "users"
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:38:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:38:36 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:38:37 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 166
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 22
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 26
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 30
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 34
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 38
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 46
ERROR - 2017-04-18 09:42:09 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 49
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 52
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 55
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 58
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 61
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 64
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 78
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "services"
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "users"
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:42:10 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:42:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 166
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 22
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 26
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 30
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 34
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 38
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 46
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 49
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 52
ERROR - 2017-04-18 09:43:10 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 55
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 58
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 61
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 64
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 78
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "services"
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "users"
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:43:11 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:43:11 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 166
ERROR - 2017-04-18 09:43:35 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 09:43:35 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 09:43:35 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 09:43:35 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 22
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 26
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 30
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 34
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 38
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 46
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 49
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 52
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 55
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 58
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 61
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 64
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 78
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "services"
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "users"
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:43:36 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:43:36 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 166
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "services"
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "users"
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:50:16 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:50:16 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "services"
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "users"
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:51:08 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:51:08 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:51:09 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:53:48 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "services"
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "users"
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:53:49 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:53:49 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:53:55 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:53:55 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:53:55 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:53:55 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:53:55 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:53:55 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:53:55 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:53:55 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:53:55 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:53:55 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:53:55 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:53:55 --> Could not find the language line "services"
ERROR - 2017-04-18 09:53:55 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:53:56 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:53:56 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:53:56 --> Could not find the language line "users"
ERROR - 2017-04-18 09:53:56 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:53:56 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:53:56 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:53:56 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:53:56 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:53:56 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:53:56 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:54:21 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:54:21 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:54:21 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:54:21 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:54:21 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:54:21 --> Could not find the language line "services"
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:54:21 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:54:22 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:54:22 --> Could not find the language line "users"
ERROR - 2017-04-18 09:54:22 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:54:22 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:54:22 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:54:22 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:54:22 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:54:22 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:54:22 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "services"
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "users"
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:55:32 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:55:32 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:55:52 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "services"
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "users"
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:55:53 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:55:53 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:55:56 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:55:56 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:55:56 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:55:56 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:55:56 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:55:56 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:55:56 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:55:56 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:55:56 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "services"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "users"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "services"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "users"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:55:57 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:55:57 --> Could not find the language line "log_out"
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 96
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 97
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "manage_appointment_record_hint"
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "calendar"
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 107
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 108
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "manage_customers_hint"
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "customers"
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 118
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 119
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "manage_services_hint"
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "services"
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 129
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 130
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "manage_users_hint"
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "users"
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 140
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: privileges C:\xampp\htdocs\helpy\application\views\includes\header.php 141
ERROR - 2017-04-18 09:55:58 --> Severity: Notice --> Undefined variable: active_menu C:\xampp\htdocs\helpy\application\views\includes\header.php 142
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "settings_hint"
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "settings"
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "log_out_hint"
ERROR - 2017-04-18 09:55:58 --> Could not find the language line "log_out"
ERROR - 2017-04-18 11:28:59 --> Could not find the language line "go_to_booking_page"
ERROR - 2017-04-18 11:28:59 --> Could not find the language line "hello"
ERROR - 2017-04-18 11:28:59 --> Severity: Notice --> Undefined variable: user_display_name C:\xampp\htdocs\helpy\application\views\includes\footer.php 10
ERROR - 2017-04-18 11:29:42 --> Could not find the language line "go_to_booking_page"
ERROR - 2017-04-18 11:30:28 --> Could not find the language line "go_to_booking_page"
ERROR - 2017-04-18 11:47:22 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\helpy\application\views\student\login.php 7
ERROR - 2017-04-18 11:52:10 --> Severity: Notice --> Undefined property: Student::$form_validation C:\xampp\htdocs\helpy\application\controllers\student.php 27
ERROR - 2017-04-18 11:52:11 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\helpy\application\controllers\student.php 27
ERROR - 2017-04-18 11:52:18 --> Severity: Notice --> Undefined property: Student::$form_validation C:\xampp\htdocs\helpy\application\controllers\student.php 54
ERROR - 2017-04-18 11:52:18 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\helpy\application\controllers\student.php 54
ERROR - 2017-04-18 11:57:50 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\helpy\application\controllers\student.php 37
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 23
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 27
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 31
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 35
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 39
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 47
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 50
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 53
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 56
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 59
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 62
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 65
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 80
ERROR - 2017-04-18 11:58:22 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 110
ERROR - 2017-04-18 11:58:57 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 23
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 27
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 31
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 35
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 39
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 47
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 50
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 53
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 56
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 59
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 62
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 65
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 80
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 110
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\student\login.php 4
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 5
ERROR - 2017-04-18 11:58:58 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 8
ERROR - 2017-04-18 11:59:32 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 11:59:32 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 23
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 27
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 31
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 35
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 39
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 47
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 50
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 53
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 56
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 59
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 62
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 65
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 80
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 110
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\student\login.php 4
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 5
ERROR - 2017-04-18 11:59:33 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 8
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 4
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 9
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 18
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 23
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 27
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 31
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 35
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 39
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 47
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 50
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 53
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 56
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 59
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 62
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 65
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 79
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: company_name C:\xampp\htdocs\helpy\application\views\includes\header.php 80
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\header.php 110
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\student\login.php 4
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 5
ERROR - 2017-04-18 11:59:54 --> Severity: Notice --> Undefined variable: base_url C:\xampp\htdocs\helpy\application\views\includes\footer.php 8
ERROR - 2017-04-18 12:00:38 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\helpy\application\views\student\login.php 7
ERROR - 2017-04-18 12:01:33 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\helpy\application\views\student\login.php 7
ERROR - 2017-04-18 12:02:20 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\helpy\application\views\student\login.php 7
ERROR - 2017-04-18 12:03:04 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\helpy\application\views\student\login.php 7
ERROR - 2017-04-18 12:33:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Post_model C:\xampp\htdocs\helpy\system\core\Loader.php 344
ERROR - 2017-04-18 12:34:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Post_model C:\xampp\htdocs\helpy\system\core\Loader.php 344
ERROR - 2017-04-18 12:34:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Post_model C:\xampp\htdocs\helpy\system\core\Loader.php 344
ERROR - 2017-04-18 12:34:39 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\helpy\application\models\Student_model.php 2
ERROR - 2017-04-18 12:34:42 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\helpy\application\models\Student_model.php 2
ERROR - 2017-04-18 12:35:03 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\helpy\application\views\student\register.php 6
ERROR - 2017-04-18 13:07:46 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\helpy\application\models\Student_model.php 27
ERROR - 2017-04-18 13:07:50 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\helpy\application\models\Student_model.php 27
ERROR - 2017-04-18 13:08:16 --> Severity: Parsing Error --> syntax error, unexpected '$user_id' (T_VARIABLE) C:\xampp\htdocs\helpy\application\controllers\student.php 81
ERROR - 2017-04-18 13:34:56 --> Severity: Error --> Call to undefined method CI_Session::user_data() C:\xampp\htdocs\helpy\application\controllers\student.php 35
ERROR - 2017-04-18 13:37:56 --> Severity: Error --> Call to undefined method Student_model::profile() C:\xampp\htdocs\helpy\application\controllers\student.php 35
ERROR - 2017-04-18 13:52:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\helpy\application\views\student\profile.php 4
ERROR - 2017-04-18 13:52:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\helpy\application\views\student\profile.php 4
ERROR - 2017-04-18 13:53:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\helpy\application\views\student\profile.php 4
ERROR - 2017-04-18 13:53:39 --> Severity: Error --> Call to undefined method stdClass::row_array() C:\xampp\htdocs\helpy\application\models\Student_model.php 55
ERROR - 2017-04-18 13:54:03 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\helpy\application\controllers\student.php 36
ERROR - 2017-04-18 13:55:32 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\helpy\application\controllers\student.php 35
ERROR - 2017-04-18 13:56:05 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\helpy\application\controllers\student.php 35
ERROR - 2017-04-18 13:57:32 --> Severity: Error --> Call to undefined function logout() C:\xampp\htdocs\helpy\application\controllers\student.php 41
ERROR - 2017-04-18 13:57:43 --> Severity: Error --> Call to undefined function logout() C:\xampp\htdocs\helpy\application\controllers\student.php 41
ERROR - 2017-04-18 13:57:50 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting '{' C:\xampp\htdocs\helpy\application\controllers\student.php 41
ERROR - 2017-04-18 14:03:26 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\helpy\application\helpers\student_helper.php 7
ERROR - 2017-04-18 14:06:12 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\helpy\application\helpers\student_helper.php 8
ERROR - 2017-04-18 14:07:02 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\helpy\application\helpers\student_helper.php 6
ERROR - 2017-04-18 14:07:37 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\helpy\application\helpers\student_helper.php 6
ERROR - 2017-04-18 14:07:55 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\helpy\application\helpers\student_helper.php 7
ERROR - 2017-04-18 14:33:33 --> Severity: Compile Error --> Cannot re-assign $this C:\xampp\htdocs\helpy\application\helpers\student_helper.php 8
ERROR - 2017-04-18 14:38:50 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\helpy\application\views\student\profile.php 3
ERROR - 2017-04-18 14:41:51 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\helpy\application\views\student\profile.php 8
ERROR - 2017-04-18 15:11:38 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\helpy\system\libraries\Session\drivers\Session_files_driver.php 122
ERROR - 2017-04-18 15:17:37 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\helpy\application\models\Student_model.php 1
ERROR - 2017-04-18 16:52:08 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\helpy\application\controllers\Backend_api.php 983
ERROR - 2017-04-18 16:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\helpy\application\models\Roles_model.php 47
ERROR - 2017-04-18 16:52:27 --> Severity: Notice --> Undefined index: provider C:\xampp\htdocs\helpy\application\controllers\Backend_api.php 980
ERROR - 2017-04-18 16:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\helpy\application\models\Roles_model.php 47
ERROR - 2017-04-18 16:56:20 --> Severity: Notice --> Undefined index: provider C:\xampp\htdocs\helpy\application\controllers\Backend_api.php 980
