<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-10 15:27:47 --> Severity: Compile Error --> Cannot use EA\Engine\Types\String as String because 'String' is a special class name C:\Users\alext\Dev\easyappointments\src\application\controllers\Backend_api.php 14
ERROR - 2016-10-10 15:32:15 --> Severity: Compile Error --> Cannot use EA\Engine\Types\Int as Int because 'Int' is a special class name C:\Users\alext\Dev\easyappointments\src\application\controllers\Backend_api.php 14
ERROR - 2016-10-10 15:33:01 --> Severity: Compile Error --> Cannot use EA\Engine\Types\Bool as Bool because 'Bool' is a special class name C:\Users\alext\Dev\easyappointments\src\application\controllers\Backend_api.php 14
ERROR - 2016-10-10 15:33:14 --> Severity: Compile Error --> Cannot use EA\Engine\Types\Float as Float because 'Float' is a special class name C:\Users\alext\Dev\easyappointments\src\application\controllers\Backend_api.php 14
